import React from "react";

export default function ContactUs() {
  return (
    <div>
      <h1 className="consulting">CONTACT US</h1>
    </div>
  );
}
