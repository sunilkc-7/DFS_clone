export const MenuItems = [
  {
    title: "Marketing",
    path: "/Marketing",
    cName: "dropdown-link",
  },
  {
    title: "Consulting",
    path: "/Consulting",
    cName: "dropdown-link",
  },
  {
    title: "Design",
    path: "/Design",
    cName: "dropdown-link",
  },
  {
    title: "Development",
    path: "/Development",
    cName: "dropdown-link",
  },
];
