import React from "react";

export default function Products() {
  return (
    <div>
      <h1 className="consulting">PRODUCT</h1>
    </div>
  );
}
