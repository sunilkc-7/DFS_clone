import React from "react";

export default function SignUp() {
  return (
    <div>
      <h1 className="consulting">SIGNUP</h1>
    </div>
  );
}
