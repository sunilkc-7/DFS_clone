import React from "react";
import { Context } from "../Context/Provider";
import "./Home.css";

const Home = () => {
  const { items, drink } = React.useContext(Context);
  console.log(drink.drinks);
  // const [drinks, setDrinks] = useState(0);
  // const [blackCoffe, setBlackCoffee] = useState(0);
  // const [milkCoffe, setMilkCoffee] = useState(0);
  // const [blackTea, setBlackTea] = useState(0);
  // const [milkTea, setMilkTea] = useState(0);

  const inputHandler = (e) => {
    drink.setDrinks({
      ...drink.drinks,
      name: e.target.name,
      value: e.target.value,
    });
  };

  return (
    <>
      <div className="headItem">
        <span className="itemName">Item</span>
        <div className="img">IMG</div>
        <span className="availableTime">Available Time</span>
        <span className="qty">Rate</span>
        <span className="initquant">Init Qty</span>
        <span className="availableQty">Avail Qty</span>
        <span className="action">Quantity</span>
        <span className="price">Price</span>
      </div>
      <div className="mainDiv">
        <div className="wrapper">
          <div className="itemHead">
            <span className="" style={{ color: "black" }}>
              Drinks Item
            </span>
            {/* 
            <span className="img"></span>
            <span className="availableTime"></span>
            <span className="qty"></span>
            <span className="availableQty"></span>
            <span className="price"></span> */}
          </div>

          {items.map((item) => {
            return (
              <div className="items" key={item.id}>
                <span className="itemName">{item.name}</span>
                <span className="img">{item.img}</span>
                <span className="availableTime">{item.time}</span>
                <span className="qty">{item.rate}</span>
                <span className="initquant">{item.initQty}</span>
                <span className="availableQty">{item.avaiQty}</span>
                <div className="action">
                  <button
                    className="btn"
                    onClick={(e) =>
                      drink.setDrinks({
                        ...drink.drinks,
                        setDrinks: drink.drinks - 1,
                      })
                    }
                  >
                    -
                  </button>
                  <input
                    className="qtyText"
                    name={drink.drinks}
                    onClick={(e) => inputHandler(e)}
                  ></input>
                  <button
                    className="btn"
                    onClick={(e) =>
                      drink.setDrinks({
                        ...drink.drinks,
                        setDrinks: drink.drinks + 1,
                      })
                    }
                  >
                    +
                  </button>
                </div>
                <span className="price">{item.price}</span>
              </div>
            );
          })}

          {/* <div className="items">
            <span className="itemName">BlackCoffe</span>
            <span className="img">img</span>
            <span className="availableTime">4:00pm - 5:00pm</span>
            <span className="qty">20</span>
            <span className="initquant">2</span>
            <span className="availableQty">10</span>
            <div className="action">
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, blackCoffe: blackCoffe - 1 })
                }
              >
                -
              </button>
              <input className="qtyText" value={drinks.blackCoffe}></input>
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, blackCoffe: blackCoffe + 1 })
                }
              >
                +
              </button>
            </div>
            <span className="price">450</span>
          </div> */}

          {/* <div className="items">
            <span className="itemName">Milk Coffee</span>
            <span className="img">img</span>
            <span className="availableTime">11:00am - 2:pm</span>
            <span className="qty">20</span>
            <span className="initquant">1</span>
            <span className="availableQty">10</span>
            <div className="action">
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, milkCoffe: milkCoffe - 1 })
                }
              >
                -
              </button>
              <input className="qtyText" value={drinks.milkCoffe}></input>
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, milkCoffe: milkCoffe + 1 })
                }
              >
                +
              </button>
            </div>
            <span className="price">350</span>
          </div>

          <div className="items">
            <span className="itemName">Black Tea</span>
            <span className="img">img</span>
            <span className="availableTime">10:00am - 3:00pm</span>
            <span className="qty">20</span>
            <span className="initquant">2</span>
            <span className="availableQty">10</span>
            <div className="action">
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, blackTea: blackTea - 1 })
                }
              >
                -
              </button>
              <input className="qtyText" value={drinks.blackTea}></input>
              <button
                className="btn"
                onClick={(e) =>
                  setDrinks({ ...drinks, blackTea: blackTea + 1 })
                }
              >
                +
              </button>
            </div>
            <span className="price">200</span>
          </div>

          <div className="items">
            <span className="itemName">Milk Tea</span>
            <span className="img">img</span>
            <span className="availableTime">11:am - 2:00pm</span>
            <span className="qty">20</span>
            <span className="initquant">2</span>
            <span className="availableQty">15</span>
            <div className="action">
              <button
                className="btn"
                onClick={(e) => setDrinks({ ...drinks, milkTea: milkTea - 1 })}
              >
                -
              </button>
              <input className="qtyText" value={drinks.milkTea}></input>
              <button
                className="btn"
                onClick={(e) => setDrinks({ ...drinks, milkTea: milkTea + 1 })}
              >
                +
              </button>
            </div>
            <span className="price">300</span>
          </div> */}
        </div>
      </div>
    </>
  );
};
export default Home;
