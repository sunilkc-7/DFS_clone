import React from "react";

export default function Marketing() {
  return (
    <div>
      <h1 className="consulting">MARKETING</h1>
    </div>
  );
}
