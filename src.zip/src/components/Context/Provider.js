import React, { createContext, useState } from "react";
export const Context = createContext();

const Provider = (props) => {
  const items = [
    {
      id: 1,
      name: "Black Coffee",
      img: "img",
      time: "9:00am - 4:00pm",
      rate: "28.5",
      initQty: "20",
      avaiQty: "2",

      price: "25",
    },
    {
      id: 2,
      name: "Milk coffee",
      img: "img",
      time: "9:00am - 4:00pm",
      rate: "28.5",
      initQty: "20",
      avaiQty: "2",
      price: "45",
    },
    {
      id: 3,
      name: "Milk Tea",
      img: "img",
      time: "9:00am - 4:00pm",
      rate: "28.5",
      initQty: "20",
      avaiQty: "2",
      price: "30",
    },
    {
      id: 4,
      name: "Black Tea",
      img: "img",
      time: "9:00am - 4:00pm",
      rate: "28.5",
      initQty: "20",
      avaiQty: "2",
      price: "20",
    },
  ];
  const [drinks, setDrinks] = useState({
    blackCoffe: 0,
    milkCoffe: 0,
    blackTea: 0,
    milkTea: 0,
  });
  return (
    <Context.Provider value={{ items, drink: { drinks, setDrinks } }}>
      {props.children}
    </Context.Provider>
  );
};

export default Provider;
