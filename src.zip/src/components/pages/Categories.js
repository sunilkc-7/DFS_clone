import React from "react";
import "./Categories.css";

function categories() {
  return (
    <div>
      <div className="search">
        <input type="text" className="searchInput" />
        <button className="searchBtn">Search</button>
      </div>
      <div className="inputFields">
        <div>
          <input type="radio" name="select" id="expand" value="Expand All" />
          <label htmlFor="expand">Expand All</label>
          <input
            type="radio"
            name="select"
            id="collapse"
            value="Collapse All"
          />
          <label htmlFor="collapse">Collapse All</label>
        </div>
        <div className="catButtons">
          <button className="catBtn">All Time</button>
          <button className="catBtn">Lunch</button>
          <button className="catBtn">Brekfast</button>
          <button className="catBtn">Snacks</button>
          <button className="catBtn">Dinner</button>
        </div>
      </div>
    </div>
  );
}

export default categories;
