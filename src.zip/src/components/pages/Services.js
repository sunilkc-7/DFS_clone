import React from "react";

export default function Services() {
  return (
    <div>
      <h1 className="consulting">Taste that best, its on time</h1>
    </div>
  );
}
