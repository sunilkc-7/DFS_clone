import React from "react";
import "./App.css";
import Navbar from "./components/Navbar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Services from "./components/pages/Services";
import Home from "./components/pages/Home";
import ContactUs from "./components/pages/ContactUs";
import Products from "./components/pages/Products";
import SignUp from "./components/pages/SignUp";
import Marketing from "./components/pages/Marketing";
import Consulting from "./components/pages/Consulting";
import Categories from "./components/pages/Categories";
import Provider from "./components/Context/Provider";

const App = () => {
  return (
    <Router>
      <Provider>
        <>
          <Navbar />
          <Categories />
          <Routes>
            <Route path="/" exact element={<Home />} />
            <Route path="/services" exact element={<Services />} />
            <Route path="/products" exact element={<Products />} />
            <Route path="/contact-us" exact element={<ContactUs />} />
            <Route path="/sign-up" exact element={<SignUp />} />
            <Route path="/marketing" exact element={<Marketing />} />
            <Route path="/consulting" exact element={<Consulting />} />
          </Routes>
        </>
      </Provider>
    </Router>
  );
};

export default App;
