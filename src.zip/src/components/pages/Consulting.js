import React from "react";

export default function Consulting() {
  return (
    <div>
      <h1 className="consulting">CONSULTING</h1>
    </div>
  );
}
